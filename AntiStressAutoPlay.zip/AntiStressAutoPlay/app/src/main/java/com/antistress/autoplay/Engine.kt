package com.antistress.autoplay

import android.content.SharedPreferences
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * "दिमाग़": स्क्रीन की तस्वीर में पीली गेंद और अपना लाल पैडल ढूँढता है।
 * v2: पैडल हर फ्रेम गेंद का पीछा नहीं करता। गेंद के पहुँचने की जगह का अंदाज़ा एक बार "तय"
 * (commit) होता है, फिर पैडल चिकनी चाल (easing) से वहाँ जाकर रुक जाता है।
 * सारे निर्देशांक capture-space में हैं (चौड़ाई ~360), स्क्रीन पर भेजते समय scale होते हैं।
 */
class Engine(
    private val screenW: Int,
    private val screenH: Int,
    private val prefs: SharedPreferences
) {
    companion object {
        const val ST_MENU = 0      // गेम नहीं दिख रहा
        const val ST_NOBALL = 1    // गेम में, गेंद नहीं दिख रही
        const val ST_TRACK = 2     // गेंद ट्रैक हो रही है
        private const val HN = 12
    }

    private class Blob(val cx: Float, val cy: Float, val area: Int)

    @Volatile
    var status = ST_MENU
        private set

    private var raw = ByteArray(0)
    private var ballMask = ByteArray(0)
    private var padMask = ByteArray(0)
    private var stack = IntArray(0)

    // गेंद का इतिहास (गति निकालने के लिए)
    private val hT = LongArray(HN)
    private val hX = FloatArray(HN)
    private val hY = FloatArray(HN)
    private var hN = 0
    private var hasBall = false
    private var lastBx = 0f
    private var lastBy = 0f
    private var lastSeen = 0L
    private var vx = 0f
    private var vy = 0f
    private var velOk = false

    // गेम में हैं या नहीं (hysteresis)
    private var inGame = false
    private var inCnt = 0
    private var outCnt = 0
    private var gestureOn = false

    // पैडल का चिकना माप और नियंत्रण की स्थिति
    private var padInit = false
    private var padX = 0f
    private var padY = 0f
    private var cmdInit = false
    private var cmdX = 0f
    private var cmdY = 0f
    private var tgtX = 0f
    private var tgtY = 0f
    private var fingerTx = 0f
    private var fingerTy = 0f
    private var lastFrameT = 0L
    private var phase = 0
    private var phaseSince = 0L
    private var force = false
    private var satCnt = 0
    private var lastRestart = 0L

    // गिनती (नोटिफिकेशन में दिखती है)
    @Volatile
    var hits = 0
        private set
    @Volatile
    var misses = 0
        private set
    private var wasApproach = false
    private var missCounted = false

    // तेज़ शॉट (स्विंग)
    @Volatile
    var smashes = 0
        private set
    private var swingPending = false
    private var swung = false
    private var swingSide = true
    private var swingUntil = 0L
    private var resync = false

    // सर्व का इंतज़ार (बल्ला कोने में)
    private var serveWait = false
    private var cornerLeft = true

    fun reset() {
        inGame = false; inCnt = 0; outCnt = 0; gestureOn = false
        hasBall = false; hN = 0; velOk = false
        padInit = false; cmdInit = false; satCnt = 0; phase = 0
        wasApproach = false; missCounted = false
        swingPending = false; swung = false; swingUntil = 0L; resync = false
        serveWait = false
    }

    fun process(buf: ByteBuffer, rowStride: Int, w: Int, h: Int, running: Boolean) {
        val now = System.nanoTime() / 1_000_000L
        val n = w * h
        if (ballMask.size != n) {
            ballMask = ByteArray(n); padMask = ByteArray(n); stack = IntArray(n)
        }
        val need = rowStride * h
        if (raw.size != need) raw = ByteArray(need)
        buf.rewind()
        buf.get(raw, 0, min(buf.remaining(), need))
        java.util.Arrays.fill(ballMask, 0)
        java.util.Arrays.fill(padMask, 0)

        val yMin = (0.155f * h).toInt()
        val yBallMax = (0.93f * h).toInt()
        var blue = 0
        for (y in 0 until h) {
            var o = y * rowStride
            val row = y * w
            for (x in 0 until w) {
                val r = raw[o].toInt() and 255
                val g = raw[o + 1].toInt() and 255
                val b = raw[o + 2].toInt() and 255
                o += 4
                if (b > 150 && b - r > 50 && b > g) blue++
                if (y >= yMin) {
                    if (r > 170 && g < 135 && b < 135 && r - g > 70) {
                        padMask[row + x] = 1
                    } else if (y < yBallMax && r > 195 && g > 190 && b in 61..199 &&
                        r - b > 45 && abs(r - g) < 50
                    ) {
                        ballMask[row + x] = 1
                    }
                }
            }
        }

        val blueOk = blue.toFloat() / n > 0.12f
        if (blueOk) { inCnt++; outCnt = 0 } else { outCnt++; inCnt = 0 }
        if (!inGame && inCnt >= 3) inGame = true
        if (inGame && outCnt >= 20) inGame = false

        val a11y = BotAccessibilityService.instance
        val scale = screenW.toFloat() / w
        val cx = w / 2f

        if (!inGame) {
            status = ST_MENU
            hasBall = false; hN = 0; velOk = false
            padInit = false; cmdInit = false
            if (gestureOn) { a11y?.end(); gestureOn = false }
            return
        }

        // ---- गेंद ----
        val ball = largest(ballMask, w, h, yMin, yBallMax, 40, 0f)
        if (ball != null) {
            if (hN > 0 && (now - hT[hN - 1] > 200 ||
                    abs(ball.cx - hX[hN - 1]) + abs(ball.cy - hY[hN - 1]) > 0.35f * w)) {
                hN = 0   // नई सर्व / गेंद गायब होकर लौटी
            }
            // 170 ms से पुराने नमूने हटाओ
            while (hN > 0 && now - hT[0] > 170) shiftHistory()
            if (hN == HN) shiftHistory()
            hT[hN] = now; hX[hN] = ball.cx; hY[hN] = ball.cy; hN++
            lastBx = ball.cx; lastBy = ball.cy; lastSeen = now
            hasBall = true
            velOk = fitVelocity()
            if (!velOk) { vx = 0f; vy = 0f }
        } else if (now - lastSeen > 300) {
            hasBall = false; velOk = false; vx = 0f; vy = 0f; hN = 0
        }
        status = if (hasBall) ST_TRACK else ST_NOBALL

        // हिट / चूक की गिनती
        if (hasBall && velOk) {
            if (vy > 60f) {
                wasApproach = true
                if (lastBy > 0.72f * h && !missCounted) { misses++; missCounted = true }
            } else if (vy < -60f) {
                if (wasApproach && lastBy > 0.4f * h && !missCounted) hits++
                wasApproach = false
                missCounted = false
            }
        }

        // ---- अपना पैडल: नीचे वाला सबसे बड़ा लाल हिस्सा (विरोधी ऊपर और छोटा है) ----
        val paddle = largest(padMask, w, h, yMin, h, 700, 0.35f * h)
        if (paddle != null) {
            if (!padInit) { padX = paddle.cx; padY = paddle.cy; padInit = true }
            else { padX += 0.5f * (paddle.cx - padX); padY += 0.5f * (paddle.cy - padY) }
        }

        if (!running) {
            if (gestureOn) { a11y?.end(); gestureOn = false }
            cmdInit = false
            lastFrameT = now
            return
        }
        if (a11y == null) return
        if (!gestureOn) {
            fingerTx = cx * scale; fingerTy = 0.82f * screenH
            a11y.begin(fingerTx, fingerTy)
            gestureOn = true
            cmdInit = false
            lastFrameT = now
            return
        }
        if (!padInit) return
        if (!cmdInit) {
            cmdX = padX; cmdY = padY; tgtX = padX; tgtY = padY
            cmdInit = true; lastFrameT = now
            return
        }

        if (now < swingUntil) { lastFrameT = now; return }   // स्विंग चल रही है
        if (resync) {
            resync = false
            cmdX = padX; cmdY = padY; tgtX = padX; tgtY = padY; force = true
        }

        val dtS = ((now - lastFrameT) / 1000f).coerceIn(0.004f, 0.05f)
        lastFrameT = now

        val smooth = prefs.getFloat("smooth", 0.6f).coerceIn(0f, 1f)
        val lookS = prefs.getFloat("look", 120f) / 1000f
        val ratio = max(0.3f, prefs.getFloat("ratio", 1.0f))
        val speed = prefs.getFloat("speed", 0.7f).coerceIn(0f, 1f)

        // ---- लक्ष्य का अंदाज़ा ----
        val hitY = 0.56f * h
        val approaching = hasBall && velOk && vy > 60f
        val staticBall = hasBall && velOk && abs(vy) <= 60f && abs(vx) <= 60f && lastBy > 0.45f * h
        val sw = !hasBall && now - lastSeen > 700
        if (sw && !serveWait) {
            cornerLeft = !cornerLeft   // हर नई सर्व पर कोना बदलो
            force = true
        }
        serveWait = sw
        val newPhase = if (approaching) 1 else if (staticBall) 2 else if (hasBall && !velOk) -1 else 0
        if (newPhase != -1 && newPhase != phase) {
            phase = newPhase; phaseSince = now; force = phase != 0
            if (phase == 1) {
                swingPending = kotlin.random.Random.nextFloat() < prefs.getFloat("smashp", 0.85f)
                swung = false
            }
        }

        val hyst = 0.05f * w
        var boost = false
        if (phase == 1 && approaching) {
            val tHit = ((hitY - lastBy) / vy).coerceIn(0f, 0.35f)
            val horizon = min(0.35f, max(tHit, lookS))
            val rawX = (lastBx + vx * horizon).coerceIn(0.05f * w, 0.95f * w)
            val rawY = (0.60f * h + 0.3f * (lastBy + 0.06f * h - 0.60f * h)).coerceIn(0.56f * h, 0.64f * h)
            // गेंद जल्दी पहुँचने वाली है और बल्ला दायरे से बाहर है: आपातकाल, तुरंत झपटो
            val miss = tHit < 0.18f && abs(rawX - padX) > 0.11f * w
            val freeze = tHit < 0.04f && !miss
            val h2 = if (tHit < 0.25f) 0.6f * hyst else hyst
            if (miss) {
                tgtX = rawX; tgtY = rawY; force = false; boost = true
            } else if (!freeze && (force || abs(rawX - tgtX) > h2 || abs(rawY - tgtY) > h2)) {
                tgtX = rawX; tgtY = rawY; force = false
            }

            // तेज़ शॉट: बल्ला गेंद के ठीक नीचे है और गेंद बस पहुँचने वाली है -> आगे की तरफ़ तेज़ झटका
            val smashLead = 0.05f + 0.12f * prefs.getFloat("smasht", 0.5f).coerceIn(0f, 1f)
            if (swingPending && !swung && !miss && tHit < smashLead &&
                lastBy < 0.68f * h && abs(padX - lastBx) < 0.13f * w
            ) {
                val power = prefs.getFloat("power", 0.6f).coerceIn(0f, 1f)
                val d = (0.03f + 0.09f * power) * screenH
                val side = if (swingSide) 1f else -1f
                swingSide = !swingSide
                val x0 = fingerTx
                val y0 = fingerTy
                val x1 = (x0 + 0.35f * d * side).coerceIn(0.03f * screenW, 0.97f * screenW)
                val y1 = (y0 - d).coerceAtLeast(0.15f * screenH)
                a11y.flick(x1, y1, 40, x0, y0, 90)
                swung = true
                smashes++
                swingUntil = now + 170
                resync = true
                return
            }
        } else if (phase == 2 && staticBall) {
            // सर्व: कोने से गेंद के आर-पार तिरछा तेज़ घुमाव (बल्ले की रफ़्तार से गेंद चलेगी)
            val dir = if (padX < lastBx) 1f else -1f
            val rawX = (lastBx + dir * 0.10f * w).coerceIn(0.03f * w, 0.97f * w)
            val rawY = (lastBy - 0.015f * h).coerceIn(0.45f * h, 0.66f * h)
            if (force || abs(rawX - tgtX) > hyst || abs(rawY - tgtY) > hyst) {
                tgtX = rawX; tgtY = rawY; force = false
            }
            boost = true
        } else if (phase == 0 && serveWait) {
            // पॉइंट खत्म: बल्ला कोने में, ताकि सर्व की गेंद ढकी न रहे
            val rawX = if (cornerLeft) 0.14f * w else 0.86f * w
            val rawY = 0.64f * h
            if (force || abs(rawX - tgtX) > 0.5f * hyst || abs(rawY - tgtY) > 0.5f * hyst) {
                tgtX = rawX; tgtY = rawY; force = false
            }
        } else if (phase == 0 && (!hasBall || velOk) && now - phaseSince > 150) {
            val rawX = cx
            val rawY = 0.60f * h
            if (abs(rawX - tgtX) > 1.5f * hyst || abs(rawY - tgtY) > 1.5f * hyst) {
                tgtX = rawX; tgtY = rawY
            }
        }

        // ---- चिकनी चाल: cmd (काल्पनिक पैडल) धीरे-धीरे लक्ष्य की तरफ़ ----
        var k = (14f - 9f * smooth) * (0.8f + 1.4f * speed)
        if (phase == 0 && !serveWait) k *= 0.5f
        var vmaxS = 1.6f + 2.4f * speed
        if (boost) { k *= 2.5f; vmaxS *= 1.6f }
        val a = 1f - exp(-k * dtS)
        val vmax = vmaxS * w * dtS
        var stepX = ((tgtX - cmdX) * a).coerceIn(-vmax, vmax)
        var stepY = ((tgtY - cmdY) * a).coerceIn(-vmax, vmax)
        if (abs(tgtX - cmdX) < 1.5f) stepX = 0f
        if (abs(tgtY - cmdY) < 1.5f) stepY = 0f
        cmdX += stepX
        cmdY += stepY

        // असली पैडल cmd से बहुत दूर हो तो धीरे से सुधार (drift correction)
        val errX = cmdX - padX
        val errY = cmdY - padY
        val tolX = 0.06f * w
        val corrX = if (abs(errX) > tolX) errX * (if (abs(errX) > 0.2f * w) 0.15f else 0.06f) else 0f
        val corrY = if (abs(errY) > tolX) errY * (if (abs(errY) > 0.2f * w) 0.15f else 0.06f) else 0f

        val dFx = (stepX + corrX) * scale / ratio
        val dFy = (stepY + corrY) * scale / ratio
        if (abs(dFx) < 0.3f && abs(dFy) < 0.3f) return   // उँगली बिल्कुल स्थिर

        val wantX = fingerTx + dFx
        val wantY = fingerTy + dFy
        val nfx = wantX.coerceIn(0.06f * screenW, 0.94f * screenW)
        val nfy = wantY.coerceIn(0.45f * screenH, 0.95f * screenH)
        val saturated = abs(nfx - wantX) > 1f || abs(nfy - wantY) > 1f
        if (saturated) {
            cmdX = padX; cmdY = padY   // उँगली किनारे पर है; cmd को असली पैडल से मिला दो
            satCnt++
        } else {
            satCnt = 0
        }

        if (satCnt > 25 && phase == 0 && now - lastRestart > 1500) {
            // उँगली किनारे पर अटकी है: उठाकर बीच में दोबारा रखो
            fingerTx = cx * scale; fingerTy = 0.82f * screenH
            a11y.restart(fingerTx, fingerTy)
            lastRestart = now
            satCnt = 0
            return
        }
        fingerTx = nfx; fingerTy = nfy
        a11y.drive(fingerTx, fingerTy)
    }

    private fun shiftHistory() {
        for (i in 1 until hN) { hT[i - 1] = hT[i]; hX[i - 1] = hX[i]; hY[i - 1] = hY[i] }
        hN--
    }

    /** पिछले कुछ नमूनों पर सीधी रेखा बिठाकर गेंद की गति (px/sec) निकालता है */
    private fun fitVelocity(): Boolean {
        if (hN < 3) return false
        val t0 = hT[hN - 1]
        var mt = 0f; var mx = 0f; var my = 0f
        for (i in 0 until hN) { mt += (hT[i] - t0) / 1000f; mx += hX[i]; my += hY[i] }
        mt /= hN; mx /= hN; my /= hN
        var stt = 0f; var stx = 0f; var sty = 0f
        for (i in 0 until hN) {
            val dt = (hT[i] - t0) / 1000f - mt
            stt += dt * dt; stx += dt * (hX[i] - mx); sty += dt * (hY[i] - my)
        }
        if (stt < 1e-6f) return false
        vx = stx / stt
        vy = sty / stt
        return true
    }

    /** mask में सबसे बड़ा जुड़ा हुआ हिस्सा ढूँढता है */
    private fun largest(
        mask: ByteArray, w: Int, h: Int, y0: Int, y1: Int, minArea: Int, minCy: Float
    ): Blob? {
        var best: Blob? = null
        for (y in y0 until y1) {
            for (x in 0 until w) {
                val i = y * w + x
                if (mask[i].toInt() != 1) continue
                var sp = 0
                stack[sp++] = i
                mask[i] = 0
                var area = 0
                var sx = 0L
                var sy = 0L
                while (sp > 0) {
                    val p = stack[--sp]
                    val py = p / w
                    val px = p - py * w
                    area++; sx += px; sy += py
                    if (px > 0 && mask[p - 1].toInt() == 1) { mask[p - 1] = 0; stack[sp++] = p - 1 }
                    if (px < w - 1 && mask[p + 1].toInt() == 1) { mask[p + 1] = 0; stack[sp++] = p + 1 }
                    if (py > 0 && mask[p - w].toInt() == 1) { mask[p - w] = 0; stack[sp++] = p - w }
                    if (py < h - 1 && mask[p + w].toInt() == 1) { mask[p + w] = 0; stack[sp++] = p + w }
                }
                if (area >= minArea) {
                    val cx = sx.toFloat() / area
                    val cy = sy.toFloat() / area
                    if (cy >= minCy && (best == null || area > best.area)) best = Blob(cx, cy, area)
                }
            }
        }
        return best
    }
}
