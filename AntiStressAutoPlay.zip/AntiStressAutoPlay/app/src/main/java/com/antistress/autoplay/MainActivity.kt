package com.antistress.autoplay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val reqCapture = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        fun text(s: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
            this.text = s
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
        }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        fun slider(label: String, key: String, lo: Float, hi: Float, def: Float, unit: String) {
            val cur = prefs.getFloat(key, def)
            val title = text("")
            fun show(v: Float) { title.text = "$label: ${"%.2f".format(v)}$unit" }
            show(cur)
            val sb = SeekBar(this).apply {
                this.max = 100
                progress = (((cur - lo) / (hi - lo)) * 100).toInt().coerceIn(0, 100)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        val v = lo + (hi - lo) * p / 100f
                        show(v)
                        prefs.edit().putFloat(key, v).apply()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            root.addView(title)
            root.addView(sb)
        }

        root.addView(text("AntiStress AutoPlay  v5.1", 24f, true))
        root.addView(text("Table Tennis गेम अपने-आप खेलने वाला फ्लोटिंग बटन (मैनुअल सेटिंग वाला वर्ज़न)।"))
        status = text("")
        root.addView(status)

        root.addView(text("स्टेप 1", 13f, true))
        root.addView(button("ओवरले अनुमति दें") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(text("स्टेप 2", 13f, true))
        root.addView(button("Accessibility सेवा चालू करें") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "'AntiStress AutoPlay' चुनकर चालू करें", Toast.LENGTH_LONG).show()
        })
        root.addView(text("स्टेप 3", 13f, true))
        root.addView(button("फ्लोटिंग बटन शुरू करें") { startBot() })

        root.addView(text(""))
        root.addView(button("बटन दिखाएँ / छुपाएँ") {
            if (BotService.alive) {
                startService(Intent(this, BotService::class.java).setAction(BotService.ACT_HIDE))
            } else {
                Toast.makeText(this, "पहले स्टेप 3 करें", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(button("पूरा बंद करें") {
            stopService(Intent(this, BotService::class.java))
        })

        root.addView(text("\nइंस्ट्रक्शन: शॉट कहाँ मारना है", 16f, true))
        root.addView(
            text(
                "खिलाड़ी हर गेंद को विरोधी (कंप्यूटर) के बल्ले से दूर वाले किनारे की तरफ़ मारने की कोशिश करता है, " +
                    "ताकि कंप्यूटर उसे खेल न पाए। विरोधी बीच में हो तो शॉट बारी-बारी से बाएँ-दाएँ जाते हैं। " +
                    "नीचे 'Aim strength' से तय करें कि निशाना कितना तगड़ा हो (0 = निशाना बंद)।",
                14f
            )
        )
        slider("Aim strength (विरोधी से दूर मारने की ताक़त)", "aim", 0f, 1f, 0.6f, "")

        root.addView(text("\nट्यूनिंग (ज़रूरत हो तो)", 16f, true))
        slider("Smoothness (ज़्यादा = बल्ला शांत/धीमा, कम = तेज़ पर ज़्यादा हिलता)", "smooth", 0f, 1f, 0.6f, "")
        slider("Speed (ज़्यादा = बल्ला तेज़ भागता है)", "speed", 0f, 1f, 0.7f, "")
        slider("Smash chance (कितनी गेंदों पर तेज़ शॉट; 0 = कभी नहीं)", "smashp", 0f, 1f, 0.85f, "")
        slider("Smash timing (झटका जल्दी चाहिए तो बढ़ाएँ, देर से चाहिए तो घटाएँ)", "smasht", 0f, 1f, 0.5f, "")
        slider("Shot power (तेज़ शॉट का ज़ोर)", "power", 0f, 1f, 0.6f, "")
        slider("Lookahead (गेंद से कितना आगे)", "look", 0f, 400f, 120f, " ms")
        slider("पैडल/उँगली अनुपात (पैडल उँगली से तेज़ चले तो बढ़ाएँ)", "ratio", 0.5f, 2.5f, 1.0f, "")

        root.addView(
            text(
                "\nइस्तेमाल: गेम में Table Tennis खोलें → ऊपर बीच वाले गोल बटन को एक बार दबाएँ (ON) → " +
                    "रोकने के लिए फिर दबाएँ (OFF)। बटन को देर तक (1+ सेकंड) दबाने पर वह छुप जाता है; " +
                    "वापस लाने के लिए स्टेटस बार नीचे खींचकर नोटिफिकेशन में 'बटन दिखाएँ' दबाएँ।\n\n" +
                    "बटन का रंग: ग्रे = बंद, नारंगी = गेम स्क्रीन नहीं दिख रही, " +
                    "नीला = गेम दिख रहा है पर गेंद नहीं, हरा = गेंद ट्रैक हो रही है।",
                14f
            )
        )

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ac = BotAccessibilityService.instance != null
        status.text = "ओवरले अनुमति: ${if (ov) "✅" else "❌"}    Accessibility: ${if (ac) "✅" else "❌"}"
    }

    private fun startBot() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "पहले स्टेप 1 करें", Toast.LENGTH_LONG).show()
            return
        }
        if (BotAccessibilityService.instance == null) {
            Toast.makeText(this, "पहले स्टेप 2 करें", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, BotService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                Toast.makeText(this, "बटन तैयार है — अब गेम खोलें", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "स्क्रीन कैप्चर की अनुमति नहीं मिली", Toast.LENGTH_LONG).show()
            }
        }
    }
}
