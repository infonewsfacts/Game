package com.antistress.autoplay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot

/**
 * "हाथ": एक उँगली को स्क्रीन पर दबाए रखता है और छोटे-छोटे टुकड़ों (strokes) में
 * उसे target की तरफ़ खींचता रहता है। Engine हर फ्रेम पर target बदलता है।
 */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BotAccessibilityService? = null
        private const val SEG_MS = 20L
    }

    private val main = Handler(Looper.getMainLooper())

    /** उँगली की मौजूदा जगह (स्क्रीन पिक्सेल) */
    @Volatile
    var fx = 0f
    @Volatile
    var fy = 0f

    @Volatile
    private var tx = 0f
    @Volatile
    private var ty = 0f

    @Volatile
    var isActive = false
        private set

    private var inFlight = false
    private var last: GestureDescription.StrokeDescription? = null
    private var restartTo: PointF? = null
    private val flickQ = java.util.ArrayDeque<FloatArray>()

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** उँगली (x,y) पर रखो और पकड़े रहो */
    fun begin(x: Float, y: Float) {
        main.post {
            fx = x; fy = y; tx = x; ty = y
            isActive = true
            pump()
        }
    }

    /** उँगली को (x,y) की तरफ़ ले जाओ */
    fun drive(x: Float, y: Float) {
        tx = x; ty = y
        main.post { pump() }
    }

    /** तेज़ झटका: (x1,y1) तक d1 ms में, फिर (x2,y2) तक d2 ms में */
    fun flick(x1: Float, y1: Float, d1: Long, x2: Float, y2: Float, d2: Long) {
        main.post {
            flickQ.clear()
            flickQ.add(floatArrayOf(x1, y1, d1.toFloat()))
            flickQ.add(floatArrayOf(x2, y2, d2.toFloat()))
            pump()
        }
    }

    /** उँगली उठाओ */
    fun end() {
        main.post {
            isActive = false
            restartTo = null
            pump()
        }
    }

    /** उँगली उठाकर (x,y) पर दोबारा रखो */
    fun restart(x: Float, y: Float) {
        main.post {
            restartTo = PointF(x, y)
            isActive = false
            pump()
        }
    }

    private fun pump() {
        if (inFlight) return
        val prev = last

        if (!isActive && prev == null) {
            val r = restartTo
            if (r != null) {
                restartTo = null
                fx = r.x; fy = r.y; tx = r.x; ty = r.y
                isActive = true
            } else {
                return
            }
        }

        val cont = isActive
        var segDur = SEG_MS
        if (cont && flickQ.isNotEmpty()) {
            val st = flickQ.poll()
            if (st != null) { tx = st[0]; ty = st[1]; segDur = st[2].toLong() }
        } else if (!cont) {
            flickQ.clear()
        }
        val x = if (cont) tx else fx
        val y = if (cont) ty else fy
        val path = Path()
        path.moveTo(fx, fy)
        if (hypot(x - fx, y - fy) > 0.5f) path.lineTo(x, y)
        val dur = if (cont) segDur else 10L

        val sd = try {
            if (prev == null) GestureDescription.StrokeDescription(path, 0, dur, cont)
            else prev.continueStroke(path, 0, dur, cont)
        } catch (e: Exception) {
            last = null
            return
        }

        inFlight = true
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(sd).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    fx = x; fy = y
                    last = if (cont) sd else null
                    inFlight = false
                    pump()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    last = null
                    inFlight = false
                    if (isActive) pump()
                }
            },
            main
        )
        if (!ok) {
            inFlight = false
            last = null
            if (isActive) main.postDelayed({ pump() }, 100)
        }
    }
}
