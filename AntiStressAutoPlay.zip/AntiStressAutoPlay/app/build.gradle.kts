plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.antistress.autoplay"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.antistress.autoplay"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "5.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
